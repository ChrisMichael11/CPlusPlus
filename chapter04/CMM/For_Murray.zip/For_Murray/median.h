#ifndef GUARD_median_h
#define GUARD_median_h

//  'median.h' -- FINAL VERSION
#include <vector>
double median(std::vector<double>);

#endif